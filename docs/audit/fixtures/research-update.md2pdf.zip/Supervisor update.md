<!-- md2pdf:{"preset":"academic","fontFamily":"serif","headingFamily":"serif","fontSize":16,"lineHeight":1.8,"spacing":1,"margin":25.4,"pageSize":"a4","accent":"#343434","titlePage":false,"title":"Pump test decision note","subtitle":"Prototype review • revision 1","author":"Engineering team — test fixture","date":"6 November 2026","header":"Supervisor review","footer":"","pageNumbers":"total","toc":false,"numberEquations":true} -->

# Modelling update

## Research question

Can a simple relationship explain the change observed in the prototype study? This short report is a synthetic test fixture for supervisor review.

## Method

We compare a baseline and a revised setup under the same assumptions. The source data are illustrative.

<figure data-label="fig:rig"><img src="assets/image-1.png" alt="Reservoir, pump and pressure sensor connected in sequence" width="900" height="260" style="width:80%;height:auto"><figcaption>Synthetic test rig and flow direction</figcaption></figure>

See [@fig:rig] for the arrangement.

<!-- pagebreak -->

## Model and assumptions

The first approximation is:

$$
y = ax+b
$$ {#eq:model}

An independent uncertainty estimate is:

$$
u_y = \sqrt{u_a^2+u_b^2}
$$ {#eq:uncertainty}

Equations [@eq:model] and [@eq:uncertainty] describe notation, not a validated engineering calculation. The inline symbol $x_i$ identifies an observation.

<!-- pagebreak -->

## Results and limitations

| Approach | Observation |
| :--- | :---: |
| Baseline | 12.0 |
| Revision | 10.8 |

: Illustrative results {#tab:study}

See [@tab:study].

> A short update should distinguish observations from assumptions.

- The sample is small.
- Repeatability needs a separate experiment.
- No causal claim is made here.

<!-- pagebreak -->

## Next steps and reading

1. Repeat the measurements.
2. Discuss the model with the supervisor.
3. Revise the uncertainty estimate.

[Example reading](https://example.com/research)

[Method reference][method]

[method]: https://example.com/method
