<!-- md2pdf:{"preset":"technical","fontFamily":"sans","headingFamily":"sans","fontSize":14,"lineHeight":1.5,"spacing":0.85,"margin":20,"pageSize":"letter","accent":"#245a81","titlePage":true,"title":"Pump test decision note","subtitle":"Prototype review • revision 1","author":"Engineering team — test fixture","date":"6 November 2026","header":"Prototype review","footer":"Draft • {page}/{pages}","pageNumbers":"total","toc":true,"numberEquations":true} -->

# Pump test decision note

## Decision

Recommend **Option B** for the next prototype. The measured gain is modest, so this note records the assumptions and evidence for colleagues.

## Calculation

For flow $Q$ and pressure rise $\Delta p$, hydraulic power is:

$$
P = Q\,\Delta p
$$ {#eq:power}

See [@eq:power] before comparing the options.

## Procedure

<figure data-label="fig:rig"><img src="assets/image-1.png" alt="Reservoir, pump and pressure sensor connected in sequence" width="900" height="260" style="width:80%;height:auto"><figcaption>Synthetic test rig and flow direction</figcaption></figure>

1. Check the sensor zero.
2. Record three readings.
3. Repeat at the same temperature.

> These are synthetic acceptance-test figures, not engineering advice.

```python
price = "$5"
example = "<img onerror=alert(1)>"
print(price, example)
```

The literal costs are \$5 and \$10.

## Reading and next steps

[Source documentation](https://example.com)

- [ ] Repeat the test
- [x] Record the assumptions

| Option | Power (W) |
| :--- | ---: |
| A \| baseline | 12.0 |
| B | 10.8 |

: Synthetic comparison results {#tab:results}



See [@tab:results].

See [@fig:rig] for the test arrangement.